import XCTest

import YokaiNoMoriTestsTests

var tests = [XCTestCaseEntry]()
tests += YokaiNoMoriTestsTests.allTests()
XCTMain(tests)