import XCTest

import YokaiNoMoriMainTests

var tests = [XCTestCaseEntry]()
tests += YokaiNoMoriMainTests.allTests()
XCTMain(tests)