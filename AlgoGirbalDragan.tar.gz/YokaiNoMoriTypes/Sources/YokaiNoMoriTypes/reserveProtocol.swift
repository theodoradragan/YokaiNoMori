import Foundation

protocol reserveProtocol : collectionPiecesProtocol {

}
