import XCTest

import YokaiNoMoriTypesTests

var tests = [XCTestCaseEntry]()
tests += YokaiNoMoriTypesTests.allTests()
XCTMain(tests)